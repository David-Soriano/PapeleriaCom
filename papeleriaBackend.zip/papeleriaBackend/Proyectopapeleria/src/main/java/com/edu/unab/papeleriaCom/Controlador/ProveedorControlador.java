package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.ProveedorModelo;
import com.edu.unab.papeleriaCom.Repositorio.ProveedorRepo;

@RestController
@RequestMapping(path = "/proveedor")
public class ProveedorControlador {
    @Autowired
    ProveedorRepo proveedorRepo;

    @GetMapping()
    public Iterable<ProveedorModelo> getAllProveedores(){;
        return proveedorRepo.findAll();
    }

    @PostMapping()
    public ProveedorModelo saveProveedor(@RequestBody ProveedorModelo proveedor){
        return proveedorRepo.save(proveedor);          
    }

    @DeleteMapping(path = "/{id}")
    public void deleteProveedorById(@PathVariable("id") int id){
        proveedorRepo.deleteById(id);
    }
}
