package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.VentaModelo;
import com.edu.unab.papeleriaCom.Repositorio.VentaRepo;

@RestController
@RequestMapping(path = "/venta")
public class VentaControlador {
    @Autowired
    VentaRepo ventaRepo;

    @GetMapping()
    public Iterable<VentaModelo> getAllVenta(){
        return ventaRepo.findAll();
    }

    @PostMapping()
    public VentaModelo saveVenta(@RequestBody VentaModelo venta){
        return ventaRepo.save(venta);
    }

    @DeleteMapping(path = "/{id}")
    public void deleteVentaById(@PathVariable("id") int id){
        ventaRepo.deleteById(id);
    }
}
