package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.ClienteModelo;
import com.edu.unab.papeleriaCom.Repositorio.ClienteRepo;

@RestController
@RequestMapping(path = "/cliente")
public class ClienteControlador {
    @Autowired
    ClienteRepo clienterepo;

    @GetMapping()
    public Iterable<ClienteModelo> getAllClientes(){
        return clienterepo.findAll();
    }
    
   @PostMapping()
   public ClienteModelo saveCliente(@RequestBody ClienteModelo cliente){
    return clienterepo.save(cliente);
   } 

   @DeleteMapping(path = "/{id}")
   public void deleteClienteById(@PathVariable("id") int id){
    clienterepo.deleteById(id);
   }

}
