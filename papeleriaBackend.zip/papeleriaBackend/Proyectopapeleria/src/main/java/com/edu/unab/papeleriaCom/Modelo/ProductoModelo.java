package com.edu.unab.papeleriaCom.Modelo;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name="producto")
public class ProductoModelo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Para que sea incrementable
    private int idProducto;
    private String descripcion;
    @Column(nullable =  false)
    private double valor;
    @Column(nullable =  false)
    private int tipo_producto;
}
