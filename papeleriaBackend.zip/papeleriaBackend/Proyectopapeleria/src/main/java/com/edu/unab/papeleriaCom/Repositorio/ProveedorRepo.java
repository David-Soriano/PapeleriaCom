package com.edu.unab.papeleriaCom.Repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.edu.unab.papeleriaCom.Modelo.ProveedorModelo;

@Repository
public interface ProveedorRepo extends CrudRepository <ProveedorModelo, Integer> {
    
}
