package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.TipoProductoModelo;
import com.edu.unab.papeleriaCom.Repositorio.TipoProductRepo;

@RestController
@RequestMapping(path = "/tipoproducto")
public class TipoProductoControlador {
    @Autowired
    TipoProductRepo tipoProductRepo;

    @GetMapping()
    public Iterable<TipoProductoModelo> getAllTipoProducto(){
        return tipoProductRepo.findAll();
    }

    @PostMapping()
    public TipoProductoModelo saveTipoProducto(@RequestBody TipoProductoModelo tipoproducto){
        return tipoProductRepo.save(tipoproducto);
    }

    @DeleteMapping(path = "/{id}")
    public void deleteTipoProductoById(@PathVariable("id") int id){
        tipoProductRepo.deleteById(id);
    }
}
