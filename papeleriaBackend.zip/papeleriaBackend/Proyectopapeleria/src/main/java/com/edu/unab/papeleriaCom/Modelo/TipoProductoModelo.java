package com.edu.unab.papeleriaCom.Modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name = "tipoProducto")
public class TipoProductoModelo {
    @Id
    private int codTipoProdructo;
    @Column(nullable = false)
    private String nombreTipo;
}
