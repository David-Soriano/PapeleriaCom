package com.edu.unab.papeleriaCom.Repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.edu.unab.papeleriaCom.Modelo.TipoProductoModelo;

@Repository
public interface TipoProductRepo extends CrudRepository <TipoProductoModelo, Integer> {
    
}
