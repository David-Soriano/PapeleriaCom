package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.ProductoModelo;
import com.edu.unab.papeleriaCom.Repositorio.ProductoRepo;

@RestController
@RequestMapping(path = "/producto")

public class ProductoControlador {
    @Autowired
    ProductoRepo productoRepo;

    @GetMapping()
    public Iterable<ProductoModelo> getAllProductos(){;
        return productoRepo.findAll();
    }
    
    @PostMapping()
    public ProductoModelo saveProducto(@RequestBody ProductoModelo producto){
        return productoRepo.save(producto);
    }

    @DeleteMapping(path = "/{id}")
    public void deleteProductoById(@PathVariable("id") int id){
        productoRepo.deleteById(id);
    }
}
