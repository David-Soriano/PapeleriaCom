package com.edu.unab.papeleriaCom.Modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name = "almacen")
public class AlmacenModelo {
    @Id
    private int idProducto;  
    @Column(nullable = false)
    private String fechaCompra; 
    @Column(nullable = false) 
    private long cantidad;
    @Column(nullable = false)   
    private int idProveedor;

}
