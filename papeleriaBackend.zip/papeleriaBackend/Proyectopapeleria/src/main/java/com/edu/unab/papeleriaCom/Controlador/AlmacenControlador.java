package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Repositorio.AlmacenRepo;
import com.edu.unab.papeleriaCom.Modelo.AlmacenModelo;

@RestController
@RequestMapping(path = "/almacen")
public class AlmacenControlador {
    @Autowired
    AlmacenRepo almacenRepo;

    @GetMapping()
    public Iterable <AlmacenModelo> getAllAlmacen(){;
        return almacenRepo.findAll();
    }

    @PostMapping()
    public AlmacenModelo saveAlmacen(@RequestBody AlmacenModelo almacen){
        return almacenRepo.save(almacen);
    }

    @DeleteMapping(path = "/{id}")
    public void deleteAlmacenById(@PathVariable("id") int id){
        almacenRepo.deleteById(id);
    }
}
