package com.edu.unab.papeleriaCom.Controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.unab.papeleriaCom.Modelo.EmpleadoModelo;
import com.edu.unab.papeleriaCom.Repositorio.EmpleadoRepo;

@RestController
@RequestMapping(path = "/empleado")
public class EmpleadoControlador {
    @Autowired
    EmpleadoRepo empleadoRepo;

    @GetMapping()
    public Iterable<EmpleadoModelo> getAllEmpleados(){
        return empleadoRepo.findAll();
    };

    @PostMapping()
        public EmpleadoModelo saveEmpleado(@RequestBody EmpleadoModelo empleado){
            return empleadoRepo.save(empleado);
        }
    

    @DeleteMapping()
        public void DeleteEmpleadoById(@PathVariable("id") int id ){
            empleadoRepo.deleteById(id);
        }
}
