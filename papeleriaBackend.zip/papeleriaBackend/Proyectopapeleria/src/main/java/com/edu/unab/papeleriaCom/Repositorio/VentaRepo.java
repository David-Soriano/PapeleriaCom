package com.edu.unab.papeleriaCom.Repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.edu.unab.papeleriaCom.Modelo.VentaModelo;

@Repository
public interface VentaRepo extends CrudRepository <VentaModelo, Integer> {
    
}
