package com.edu.unab.papeleriaCom.Modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name = "detalleVenta")
public class DetalleVentaModelo {
    @Id
    @Column(nullable = false)
    private int idVenta;
    @Column(nullable = false)
    private int idProducto;
    @Column(nullable = false)
    private int Cantidad;
}
