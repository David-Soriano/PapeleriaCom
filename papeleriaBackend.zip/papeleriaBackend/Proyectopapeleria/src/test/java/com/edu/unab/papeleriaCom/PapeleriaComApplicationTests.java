package com.edu.unab.papeleriaCom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PapeleriaComApplicationTests {

	@Test
	void contextLoads() {
	}

}
